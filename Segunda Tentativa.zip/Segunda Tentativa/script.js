document.getElementById('design-card').addEventListener('click', function() {
    this.open = true;
});